<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title></title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<link rel="stylesheet" href=".././style.css">

</head>
<body>
<div class="nav-wrap" style="height:80px;">
		<div id="nav-icon" onclick="w3_open()"></div>
    <div class="logo">
      <a href="/"><img src="/assets/img/fastag-nav-logo.png" alt="FasTag Logo"></a>
    </div>
		<div id="top-nav">
			<ul class="menu">
			    <li style="border-right: 2px solid #f8f8f8;"><a href="/">HOME</a></li>
				<li style="border-right: 2px solid #f8f8f8;"><a href="/">FASTAG REGISTRATION</a></li>
					<li style="border-right: 2px solid #f8f8f8;"><a href="./fastag-recharge.php">FASTAG RECHARGE</a></li>
				<li style="border-right: 2px solid #f8f8f8;"><a href=".././enquiry.php">ENQUIRY</a></li>
				<!-- <li><a href="fees-and-charges.php">Fees and Charges</a></li> -->
				<li style="border-right: 2px solid #f8f8f8;"><a href=".././faqs.php">FAQs</a></li>
				<li style=""><a href=".././blog-post/">BLOG</a></li>
        <!-- <li style="border-right: 2px solid #f8f8f8;" ><a href="./complaint-form.php">COMPLAINT</a></li>
				<li><a href="./complaint-track-form.php">TRACK COMPLAINT</a></li> -->

			</ul>
		</div>
    <div style=""  class="googe_searchbar"id="google_search_input">
      <script async src="https://cse.google.com/cse.js?cx=007019498718139788174:amtiepdpgeg" >
      </script>
        <div class="gcse-search"></div>

    </div>
	</div>
  <!-- Sidebar -->
  <div class="w3-sidebar w3-bar-block w3-border-right text-muted" style="display:none;width:0;" id="mySidebarfast">
    <span   class="w3-bar-item w3-large"><b>Menu</b><span onclick="w3_close()"style="margin-left: 51%;" >&times;</span></span>
     <a href="/" class="w3-bar-item w3-button text-decoration-none">HOME</a>
    <a href="/" class="w3-bar-item w3-button text-decoration-none">FASTAG REGISTRATION</a>
     <a href="./fastag-recharge.php" class="w3-bar-item w3-button text-decoration-none">FASTAG RECHARGE</a>
    <a href=".././enquiry.php" class="w3-bar-item w3-button text-decoration-none">ENQUIRY</a>
    <a href=".././faqs.php" class="w3-bar-item w3-button text-decoration-none">FAQs</a>
    <a href=".././blog-post/" class="w3-bar-item w3-button text-decoration-none">BLOG</a>
    <a href=".././complaint-form.php" class="w3-bar-item w3-button text-decoration-none">COMPLAINT</a>
    <a href=".././complaint-track-form.php" class="w3-bar-item w3-button text-decoration-none">TRACK COMPLAINT</a>
  </div>
<script>
function w3_open() {
  document.getElementById("mySidebarfast").style.display = "block";
  document.getElementById("mySidebarfast").style.width = "auto";
}

function w3_close() {
  document.getElementById("mySidebarfast").style.display = "none";
  document.getElementById("mySidebarfast").style.width = "0";
}
</script>
</body>
</html>
<!-- Global site tag (gtag.js) - Google Ads: 436242631 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-436242631"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-436242631');
</script>
