<?php
$host = "localhost";
$userName = "u351579040_crm";
$password = "freeDOM@091#";
$dbName = "u351579040_crm";


// create connection
$conn = new mysqli($host, $userName, $password, $dbName);

// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
