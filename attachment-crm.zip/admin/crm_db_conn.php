<?php
$crm_servername = "46.17.175.64";
$crm_username = "u351579040_crm";
$crm_password = "freeDOM@091#";
$crm_dbname = "u351579040_crm";
?>
